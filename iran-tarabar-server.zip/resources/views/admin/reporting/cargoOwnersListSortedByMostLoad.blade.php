@extends('layouts.dashboard')

@section('content')

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            لیست صاحب بارها به ترتیب بیشترین بار
        </li>
    </ol>

    <div class="container text-right">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>#</th>
            </tr>
            </thead>
        </table>
    </div>
@stop



