<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FleetOperator extends Model
{
    protected $fillable = ['operator_id', 'fleet_id'];
}
